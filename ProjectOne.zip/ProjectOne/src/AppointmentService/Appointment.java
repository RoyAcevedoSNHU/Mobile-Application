package AppointmentService;

/**
 * Represents an Appointment object with fields for ID, task, contact, date, and location.
 * This class is a part of the AppointmentService.
 * Developer: Roy Acevedo
 */
public class Appointment {

    private String appointmentId;
    private String taskId;
    private String contactId;
    private String appointmentDate;
    private String location;

    // Constructor
    public Appointment(String appointmentId, String taskId, String contactId, String appointmentDate, String location) {
        this.appointmentId = appointmentId;
        this.taskId = taskId;
        this.contactId = contactId;
        this.appointmentDate = appointmentDate;
        this.location = location;
    }

    // Getter and Setter Methods
    public String getAppointmentId() {
        return appointmentId;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getContactId() {
        return contactId;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public String getLocation() {
        return location;
    }
}
