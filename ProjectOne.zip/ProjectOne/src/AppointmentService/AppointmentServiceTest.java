package AppointmentService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the AppointmentService functionality.
 * Developer: Roy Acevedo
 */
public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("A001", "T001", "C001", "2024-12-10", "Office");
        service.addAppointment(appointment);

        assertNotNull(service.getAppointment("A001"));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("A001", "T001", "C001", "2024-12-10", "Office");
        service.addAppointment(appointment);
        service.deleteAppointment("A001");

        assertNull(service.getAppointment("A001"));
    }
}
