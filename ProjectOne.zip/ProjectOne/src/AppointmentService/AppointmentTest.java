package AppointmentService;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the functionality of the Appointment class.
 * Developer: Roy Acevedo
 */
public class AppointmentTest {

    /**
     * Test method to verify that an Appointment can be created successfully.
     */
    @Test
    public void testCreateAppointment() {
        // Create a valid appointment date
        Date futureDate = new Date(System.currentTimeMillis() + 100000L);  // Future date

        // Create an Appointment instance
        Appointment appointment = new Appointment("A001", futureDate, "Doctor's Appointment");

        // Verify that the Appointment is created with the correct ID and description
        assertNotNull(appointment);
        assertEquals("A001", appointment.getAppointmentId());
        assertEquals("Doctor's Appointment", appointment.getDescription());
        assertEquals(futureDate, appointment.getAppointmentDate());
    }

    /**
     * Test method to verify that creating an Appointment with a null ID throws an exception.
     */
    @Test
    public void testAppointmentIdNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000L);
        
        // Verify that an exception is thrown when the appointment ID is null
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor's Appointment");
        });
        assertEquals("Appointment ID cannot be null or empty.", exception.getMessage());
    }

    /**
     * Test method to verify that the Appointment ID cannot exceed 10 characters.
     */
    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000L);
        
        // Verify that an exception is thrown when the appointment ID is too long
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A001LongerThanTenChars", futureDate, "Doctor's Appointment");
        });
        assertEquals("Appointment ID cannot be longer than 10 characters.", exception.getMessage());
    }

    /**
     * Test method to verify that the appointment date cannot be in the past.
     */
    @Test
    public void testAppointmentDateInThePast() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000L);  // Past date

        // Verify that an exception is thrown when the appointment date is in the past
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A001", pastDate, "Doctor's Appointment");
        });
        assertEquals("Appointment date cannot be in the past.", exception.getMessage());
    }

    /**
     * Test method to verify that the appointment description cannot be null.
     */
    @Test
    public void testAppointmentDescriptionNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000L);

        // Verify that an exception is thrown when the description is null
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A001", futureDate, null);
        });
        assertEquals("Description cannot be null.", exception.getMessage());
    }

    /**
     * Test method to verify that the appointment description cannot exceed 50 characters.
     */
    @Test
    public void testAppointmentDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000L);

        // Verify that an exception is thrown when the description is too long
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A001", futureDate, "This description is definitely longer than fifty characters. It should fail.");
        });
        assertEquals("Description cannot be longer than 50 characters.", exception.getMessage());
    }
}
