package AppointmentService;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class that provides operations to manage appointments.
 * Developer: Roy Acevedo
 */
public class AppointmentService {

    private Map<String, Appointment> appointmentMap = new HashMap<>();

    // Add an appointment
    public void addAppointment(Appointment appointment) {
        appointmentMap.put(appointment.getAppointmentId(), appointment);
    }

    // Delete an appointment by appointmentId
    public void deleteAppointment(String appointmentId) {
        appointmentMap.remove(appointmentId);
    }

    // Get an appointment by appointmentId
    public Appointment getAppointment(String appointmentId) {
        return appointmentMap.get(appointmentId);
    }
}
