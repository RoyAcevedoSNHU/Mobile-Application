package ContactService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the Contact class functionality.
 * Developer: Roy Acevedo
 */
public class ContactTest {

    @Test
    public void testContactCreation() {
        Contact contact = new Contact("C001", "John", "Doe", "1234567890", "123 Main St");
        assertNotNull(contact);
    }

    @Test
    public void testInvalidContactId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C001LongID", "John", "Doe", "1234567890", "123 Main St");
        });
        assertEquals("Contact ID must not be null and no longer than 10 characters.", exception.getMessage());
    }

    @Test
    public void testInvalidPhoneNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C001", "John", "Doe", "12345", "123 Main St");
        });
        assertEquals("Phone number must be exactly 10 digits.", exception.getMessage());
    }
}
