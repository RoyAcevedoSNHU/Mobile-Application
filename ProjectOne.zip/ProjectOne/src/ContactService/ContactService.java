package ContactService;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class that provides operations to manage contacts.
 * Developer: Roy Acevedo
 */
public class ContactService {

    // Map to store contacts, using contactId as key
    private Map<String, Contact> contactMap = new HashMap<>();

    // Add a new contact
    public void addContact(Contact contact) {
        if (contactMap.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contactMap.put(contact.getContactId(), contact);
    }

    // Delete a contact by contactId
    public void deleteContact(String contactId) {
        if (!contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contactMap.remove(contactId);
    }

    // Update the contact details by contactId
    public void updateContact(String contactId, Contact updatedContact) {
        if (!contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contactMap.put(contactId, updatedContact);
    }

    // Get a contact by contactId
    public Contact getContact(String contactId) {
        return contactMap.get(contactId);
    }
}
