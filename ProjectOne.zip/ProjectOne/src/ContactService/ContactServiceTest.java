package ContactService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the ContactService functionality.
 * Developer: Roy Acevedo
 */
public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("C001", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);
        assertNotNull(service.getContact("C001"));
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("C001", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);
        service.deleteContact("C001");

        assertNull(service.getContact("C001"));
    }

    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("C001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        Contact updatedContact = new Contact("C001", "John", "Smith", "0987654321", "456 Elm St");
        service.updateContact("C001", updatedContact);

        assertEquals("Smith", service.getContact("C001").getLastName());
    }
}
