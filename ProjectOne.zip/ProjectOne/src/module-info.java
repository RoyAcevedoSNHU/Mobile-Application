/**
 * Module definition for ProjectOne.
 * Developed by Roy Acevedo.
 */
module ProjectOne {
    // Requires Java base module (implicitly included but can be explicitly declared)
    requires java.base;

    // Requires JUnit 5 API for testing
    requires org.junit.jupiter.api;

    // Export service packages to allow external usage if necessary
    exports ContactService;
    exports TaskService;
    exports AppointmentService;

    // Open service packages for JUnit testing (allows reflection)
    opens ContactService to org.junit.platform.commons;
    opens TaskService to org.junit.platform.commons;
    opens AppointmentService to org.junit.platform.commons;
}
