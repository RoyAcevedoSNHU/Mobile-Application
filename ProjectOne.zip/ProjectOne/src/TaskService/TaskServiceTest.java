package TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the functionality of the TaskService class.
 * Developer: Roy Acevedo
 */
public class TaskServiceTest {

    /**
     * Test method to verify that a task can be successfully added to the TaskService.
     */
    @Test
    public void testAddTask() {
        // Create a TaskService instance
        TaskService service = new TaskService();
        
        // Create a Task instance
        Task task = new Task("T001", "Task1", "Complete the assignment");

        // Add the task to the service
        service.addTask(task);
        
        // Verify that the task was added by checking if it's retrievable
        assertNotNull(service.getTask("T001"));
    }

    /**
     * Test method to verify that attempting to add a task with an existing ID throws an exception.
     */
    @Test
    public void testAddDuplicateTask() {
        TaskService service = new TaskService();
        Task task1 = new Task("T001", "Task1", "Complete the assignment");
        service.addTask(task1);

        // Try to add a task with the same ID
        Task task2 = new Task("T001", "Task2", "Complete the report");

        // Verify that an exception is thrown
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
        assertEquals("Task ID already exists.", exception.getMessage());
    }

    /**
     * Test method to verify that a task can be successfully deleted from the TaskService.
     */
    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("T001", "Task1", "Complete the assignment");

        // Add the task to the service
        service.addTask(task);
        
        // Delete the task
        service.deleteTask("T001");

        // Verify that the task is deleted by checking if it's retrievable
        assertNull(service.getTask("T001"));
    }

    /**
     * Test method to verify that updating a task works as expected.
     */
    @Test
    public void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("T001", "Task1", "Complete the assignment");

        // Add the task to the service
        service.addTask(task);

        // Create an updated task
        Task updatedTask = new Task("T001", "Updated Task", "Complete the project report");

        // Update the task in the service
        service.updateTask("T001", updatedTask);

        // Verify that the task was updated by checking its new name
        assertEquals("Updated Task", service.getTask("T001").getName());
        assertEquals("Complete the project report", service.getTask("T001").getDescription());
    }

    /**
     * Test method to verify that attempting to update a task that doesn't exist throws an exception.
     */
    @Test
    public void testUpdateNonExistentTask() {
        TaskService service = new TaskService();
        Task task = new Task("T001", "Task1", "Complete the assignment");
        
        // Verify that updating a non-existent task throws an exception
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("T002", task); // T002 does not exist
        });
        assertEquals("Task ID not found.", exception.getMessage());
    }

    /**
     * Test method to verify that attempting to delete a task that doesn't exist throws an exception.
     */
    @Test
    public void testDeleteNonExistentTask() {
        TaskService service = new TaskService();
        
        // Verify that deleting a non-existent task throws an exception
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("T002"); // T002 does not exist
        });
        assertEquals("Task ID not found.", exception.getMessage());
    }
}
