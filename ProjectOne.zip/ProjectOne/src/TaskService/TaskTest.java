package TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit test class to verify the Task class functionality.
 * Developer: Roy Acevedo
 */
public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("T001", "Task1", "Complete the assignment");
        assertNotNull(task);
    }

    @Test
    public void testInvalidTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001LongID", "Task1", "Complete the assignment");
        });
        assertEquals("Task ID must not be null and no longer than 10 characters.", exception.getMessage());
    }
}
