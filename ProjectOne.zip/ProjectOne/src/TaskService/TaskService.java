package TaskService;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class that provides operations to manage tasks.
 * Developer: Roy Acevedo
 */
public class TaskService {

    private Map<String, Task> taskMap = new HashMap<>();

    // Add a new task
    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }
        taskMap.put(task.getTaskId(), task);
    }

    // Delete a task by taskId
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.remove(taskId);
    }

    // Update task details by taskId
    public void updateTask(String taskId, Task updatedTask) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.put(taskId, updatedTask);
    }

    // Get a task by taskId
    public Task getTask(String taskId) {
        return taskMap.get(taskId);
    }
}
